from setuptools import setup

setup(
      name='distributions_by_rafi',
      version='0.1',
      description='Gaussian and Binomial distributions',
      packages=['distributions_by_rafi'],
      author='Md Rafi Akhtar',
      zip_safe=False
)
